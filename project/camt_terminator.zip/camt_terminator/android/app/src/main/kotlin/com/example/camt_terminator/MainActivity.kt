package com.example.camt_terminator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
