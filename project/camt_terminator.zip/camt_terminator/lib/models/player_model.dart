import 'package:camt_terminator/models/card.dart';

class Player {
  num hp = 50;
  List<Card> hand = [];
  List<Card> deck = [];

  num get maxHp => 50;
  // etc.
}
